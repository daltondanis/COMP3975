<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/


/*
 *  Route::get($uri, $callback);
    Route::post($uri, $callback);
    Route::put($uri, $callback);
    Route::patch($uri, $callback);
    Route::delete($uri, $callback);
    Route::options($uri, $callback);
 *
 *  these files are automatically loaded by the framework
 */



Route::group(['middleware'=> ['web']], function() {

    Route::get('/', function () {
        // the first arg is the name of the view file in the resources/views
        // The second argument is an array of data that should be made available to the view. In this case,
        // we are passing the name variable, which is displayed in the view using Blade syntax.
        // using global view helper
        return view('welcome', ['name' => 'Lei Pei']);
    });

    /*
    Route::post('/signup', [
       'uses' => 'UserController@postSignUp',
        'as' => 'signup'
    ]);
    */
});


Route::get('/user/activation/{token}', 'Auth\RegisterController@userActivation');

Route::get('/test', 'UserController@test');




// show all of the customers
Route::get('customer', 'CustomerController@showAll');

Route::get('/admin/profile', function () {
   return view('admin.profile', ['data' => 'BCIT']);
});




Route::get('customer/directions', array('uses' => 'CustomerController@showDirections',
    'as' => 'directionA'));

Route::get('customer/{id}', 'CustomerController@customer');


/**
 * the first parameter is the request term that we are looking for
 */
Route::get('about', function() {
   return view('home');
});

// named routes (check this out)
Route::get('about/directions', array('as' =>'directions', function() {
    $theURL = URL::route('directions');
    return "DIRECTIONS go to this URL: $theURL";
}));


/*
 *  responds to all HTTP verbs using the any method
 * */
Route::any('submit-form', function() {
    echo 'Process FORM<br/>';
    echo date('Y-m-j', time());
});

// the function is called closure
Route::get('about/{theSubject}', function($theSubject) {
    return $theSubject . '  content goes here';
});

Route::get('about/classes/{theSubject}', function($theSubject) {
    return "Content on $theSubject";
});

Route::get('about/classes/{theArt}/{theSpecialty}', function ($theArt, $theSpecialty) {
    return "hi $theArt in $theSpecialty";
});


// redirect one path request to another
Route::get('where', function () {
   return Redirect::to('about/directions');
});
Auth::routes();

Route::get('/home', 'HomeController@index');
