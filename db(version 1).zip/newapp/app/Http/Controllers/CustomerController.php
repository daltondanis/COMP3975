<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\URL;
use App\Customer;
use App\MyStudents;

class CustomerController extends Controller
{
    public function customer($id) {
        $customer = Customer::find($id);
        //way 1
        // return view('customer', compact('customer'));
        echo $customer->name;
        // way 2
        // return view('customer', array('customer' => $customer));
    }

    public function showDirections() {
        $theURL = URL::route('directionA');
        return "DIRECTIONS go to this URL: $theURL";
    }

    public function showAll() {
        $customer = Customer::find(2);
        echo $customer->name;
    }
}
