<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\User;

class UserController extends Controller
{
    public function postSignUp(Request $request) {
        $email      = $request['email'];
        $first_name = $request['first_name'];

        // get the password and encrypt it
        $password   = bcrypt($request['password']);

        // new instance of the user object
        $user = new User();
        // access the fields in our database
        $user->email      = $email;
        $user->first_name = $first_name;
        $user->password   = $password;

        $user->save(); // write this to database
        return redirect()->back();

        // go to profile route
        // return redirect()->route('profile');

    }

    public function postSignIn(Request $request) {

    }

    public function test() {
        /*
        foreach (User::where('name', 'Arnold Myint')->cursor() as $u) {
            echo $u->email;
        }
        */
     }
}
