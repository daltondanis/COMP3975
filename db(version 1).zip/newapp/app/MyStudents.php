<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MyStudents extends Model
{
    //
}
