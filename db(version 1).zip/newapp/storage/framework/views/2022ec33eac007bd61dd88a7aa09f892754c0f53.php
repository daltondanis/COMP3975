<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin</title>
    <link rel="stylesheet" href="<?php echo e(asset('/css/main.css')); ?>" >
</head>
<body>
   <h2 class="highlight">Showing the <?php echo e($data); ?></h2>
</body>
</html>