Welcome, <?php echo e($name); ?>


Please active your account : <?php echo e(url('user/activation', $link)); ?>