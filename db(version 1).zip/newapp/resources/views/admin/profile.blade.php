<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin</title>
    <link rel="stylesheet" href="{{ asset('/css/main.css') }}" >
</head>
<body>
   <h2 class="highlight">Showing the {{ $data }}</h2>
</body>
</html>