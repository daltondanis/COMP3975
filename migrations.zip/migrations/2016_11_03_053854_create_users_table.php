<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->increments('id');
            // $table->timestamps();
            $table->string('name');
            $table->string('email')->unique();
            $table->string('password');
            //$table->string('email');
            //$table->string('first_name');
            //$table->string('password');
            $table->rememberToken();
            $table->timestamps(); // this will create two cols, one for create one for update
            // $table->boolean('activated')->default(false);
            // $table->string('token')->index();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
